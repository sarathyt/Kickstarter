package neu.edu.bean;

public class AddServiceBean {

	String addservicename;
	String addcost;
	public AddServiceBean(String addservicename, String addcost) {
		super();
		this.addservicename = addservicename;
		this.addcost = addcost;
	}
	
	public AddServiceBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getAddservicename() {
		return addservicename;
	}
	public void setAddservicename(String addservicename) {
		this.addservicename = addservicename;
	}
	public String getAddcost() {
		return addcost;
	}
	public void setAddcost(String addcost) {
		this.addcost = addcost;
	}
	
	
}
