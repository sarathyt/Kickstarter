package neu.edu.bean;

public class CategoryBean {
	
	private String categoryName;
	
	
	public CategoryBean(){
		
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	
	
}

