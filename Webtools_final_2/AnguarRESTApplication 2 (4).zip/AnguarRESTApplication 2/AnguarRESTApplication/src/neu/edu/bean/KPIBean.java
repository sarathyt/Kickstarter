package neu.edu.bean;

public class KPIBean {

	String totalprojectcount;
	String projectreachedgoal;
	String catergorycount;
	String projwithhighestbackers;

	public KPIBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KPIBean(String totalprojectcount, String projectreachedgoal, String catergorycount,
			String projwithhighestbackers) {
		super();
		this.totalprojectcount = totalprojectcount;
		this.projectreachedgoal = projectreachedgoal;
		this.catergorycount = catergorycount;
		this.projwithhighestbackers = projwithhighestbackers;
	}

	public String getTotalprojectcount() {
		return totalprojectcount;
	}

	public void setTotalprojectcount(String totalprojectcount) {
		this.totalprojectcount = totalprojectcount;
	}

	public String getProjectreachedgoal() {
		return projectreachedgoal;
	}

	public void setProjectreachedgoal(String projectreachedgoal) {
		this.projectreachedgoal = projectreachedgoal;
	}

	public String getCatergorycount() {
		return catergorycount;
	}

	public void setCatergorycount(String catergorycount) {
		this.catergorycount = catergorycount;
	}

	public String getProjwithhighestbackers() {
		return projwithhighestbackers;
	}

	public void setProjwithhighestbackers(String projwithhighestbackers) {
		this.projwithhighestbackers = projwithhighestbackers;
	}

}
