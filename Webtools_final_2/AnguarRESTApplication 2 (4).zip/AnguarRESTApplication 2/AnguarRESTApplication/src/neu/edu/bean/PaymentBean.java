package neu.edu.bean;

public class PaymentBean {

	String paymentamount;
	String modeofpayment;
	String cardnumber;
	
	
	
	public PaymentBean() {
		
		// TODO Auto-generated constructor stub
	}



	public PaymentBean(String paymentamount, String modeofpayment, String cardnumber) {
		super();
		this.paymentamount = paymentamount;
		this.modeofpayment = modeofpayment;
		this.cardnumber = cardnumber;
	}



	public String getPaymentamount() {
		return paymentamount;
	}



	public void setPaymentamount(String paymentamount) {
		this.paymentamount = paymentamount;
	}



	public String getModeofpayment() {
		return modeofpayment;
	}



	public void setModeofpayment(String modeofpayment) {
		this.modeofpayment = modeofpayment;
	}



	public String getCardnumber() {
		return cardnumber;
	}



	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}




}
