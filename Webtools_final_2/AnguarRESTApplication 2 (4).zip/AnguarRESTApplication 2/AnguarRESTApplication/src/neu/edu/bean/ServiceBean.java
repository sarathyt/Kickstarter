
package neu.edu.bean;

public class ServiceBean {
	private String servicename;
	private String cost;
    private String id;

	
	
	public ServiceBean() {
		// TODO Auto-generated constructor stub
	}
	





	public ServiceBean(String servicename, String cost, String id) {
		super();
		this.servicename = servicename;
		this.cost = cost;
		this.id = id;
	}






	public String getServicename() {
		return servicename;
	}



	public void setServicename(String servicename) {
		this.servicename = servicename;
	}



	public String getCost() {
		return cost;
	}



	public void setCost(String cost) {
		this.cost = cost;
	}






	public String getId() {
		return id;
	}






	public void setId(String id) {
		this.id = id;
	}




}
