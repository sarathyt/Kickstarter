package neu.edu.bean;

public class UpdateProjectStatBean {

	String status;
	
	
	public UpdateProjectStatBean() {
		// TODO Auto-generated constructor stub
	}
	

	public UpdateProjectStatBean(String status) {
		super();
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
