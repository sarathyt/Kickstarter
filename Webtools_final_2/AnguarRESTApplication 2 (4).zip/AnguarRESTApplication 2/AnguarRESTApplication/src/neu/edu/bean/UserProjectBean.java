package neu.edu.bean;




public class UserProjectBean {

	private String name;
	private String desc;
	private String categoryName;
	private String location;
	private String backers;
	private String amount;
	private String projectDuration;
	private String startDate;
	private String status;

	public UserProjectBean() {
	}

	public UserProjectBean(String name, String desc,String categoryName,String location, String backers,String amount,String projectDuration,String startDate,String status ) {
		super();
		this.name = name;
		this.desc = desc;
		this.location=location;
		this.backers=backers;
		this.categoryName=categoryName;
		this.projectDuration=projectDuration;
		this.status=status;
		this.amount=amount;
		this.startDate=startDate;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getBackers() {
		return backers;
	}

	public void setBackers(String backers) {
		this.backers = backers;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getProjectDuration() {
		return projectDuration;
	}

	public void setProjectDuration(String projectDuration) {
		this.projectDuration = projectDuration;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}



}
