package neu.edu.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import neu.edu.bean.CategoryBean;
import neu.edu.bean.UpdateProjectStatBean;
import neu.edu.bean.UserProjectBean;
import neu.edu.entity.Category;
import neu.edu.service.CategoryService;
import neu.edu.service.DisableProjService;
import neu.edu.service.ProjectService;

@Controller
@Path("/admin/project")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public class DisableProject {

	@Autowired
	private DisableProjService disableProjService;


	@POST
	@Path("/disable/{projName}/")
	public Response disableProj(UpdateProjectStatBean updateStatBean,@PathParam("projName") String projName) {
		

		Integer cat = disableProjService.disableProj(updateStatBean,projName);

		return Response.ok().status(200).entity(cat).build();

	}
	
	
	

}