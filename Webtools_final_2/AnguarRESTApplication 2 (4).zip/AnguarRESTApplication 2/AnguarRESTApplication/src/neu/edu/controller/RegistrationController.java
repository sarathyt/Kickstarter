package neu.edu.controller;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.crypto.NoSuchPaddingException;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import neu.edu.bean.CategoryBean;
import neu.edu.bean.UserRegistrationBean;
import neu.edu.entity.Category;
import neu.edu.security.EncryptDecrypt;
import neu.edu.service.CategoryService;
import neu.edu.service.RegisterService;

@Controller
@Path("/registration")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public class RegistrationController {

	@Autowired
	private  RegisterService regService;

	

	@POST
	@Path("/add")
	public Response addRegistration(UserRegistrationBean userRegBean) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
		System.out.println("add reg method called");

//		//Category cat = categoryService.addCategory(name);
//		String passwordUser=userRegBean.getPassword();
//		EncryptDecrypt ed=EncryptDecrypt.getInstance();
//		//String pass=null;
//		String pass=ed.encrypt(passwordUser);
//		userRegBean.setPassword(pass);
		Integer id=regService.createUser(userRegBean);

		return Response.ok().status(200).entity(id).build();

	}
	
	
}
