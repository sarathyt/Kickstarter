package neu.edu.dao;

import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import neu.edu.bean.PaymentBean;
import neu.edu.bean.UserProjectBean;
import neu.edu.bean.UserRegistrationBean;
import neu.edu.entity.Category;
import neu.edu.entity.Payment;
import neu.edu.entity.Projservice;
import neu.edu.entity.UserAccount;
import neu.edu.entity.UserProject;
import neu.edu.entity.UserProjectId;

@Repository
public class UserDAO {

	@Autowired
	private SessionFactory sessionFactory;

	
	public UserAccount validateUser(String username, String password) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from UserAccount where userName=:username and password=:password ");
		query.setString("username", username);
		query.setString("password", password);

		UserAccount user = (UserAccount) query.uniqueResult();

		return user;

	}
	
	@Transactional
	public UserAccount createUser(UserAccount userAccount) {
		Session session = sessionFactory.openSession();
		session.save(userAccount);
		return userAccount;
	}

	public UserAccount fetchUserAccount(Integer userId) {
		Session session = sessionFactory.openSession();
		return session.load(UserAccount.class, userId);
	}

	@Transactional
	public boolean addProject(UserProjectBean userProjBean,Integer UserId) {
		
		// TODO Auto-generated method stub
		System.out.println("im am here");
		Session session = sessionFactory.openSession();
//		
//		UserProjectId userProjectId = new UserProjectId(userId, userProjectBean.getName());
//		UserProject userProject = new UserProject();
//		userProject.setId(userProjectId);
//		userProject.setDescription(userProjectBean.getDesc());
		UserProjectId userProjectId = new UserProjectId(UserId, userProjBean.getName());
		UserProject up=new UserProject();
	    up.setId(userProjectId);
		Category c=new Category();
		c.setCatergoryName(userProjBean.getCategoryName());
		up.setDescription(userProjBean.getDesc());
		up.setCategory(c);
		up.setFundingDuration(userProjBean.getProjectDuration());
		// 2017-12-31
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		if (userProjBean.getStartDate()!= null) {
			try {
				up.setStartDate(sdf.parse(userProjBean.getStartDate()));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (userProjBean.getAmount() != null) {
			up.setAmountRequired(Double.parseDouble(userProjBean.getAmount()));
		}
		
		session.save(up);
		session.flush();
		return true;
	}

	@Transactional
	public boolean updateProject(UserProjectBean userProjectBean, Integer userId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		
		UserProjectId userProjectId = new UserProjectId(userId, userProjectBean.getName());
		UserProject userProject = new UserProject();
		userProject.setId(userProjectId);
		userProject.setDescription(userProjectBean.getDesc());
		
		session.save(userProject);
		session.flush();

		return true;
	}	
	public Integer disableProj(String projName) {
		Session session = sessionFactory.openSession();
		String status="invalid";
		Query query = session.createSQLQuery("Update user_project set status=:status where name =:projName");
		query.setString("status", status);
		query.setString("projName", projName);
		Integer a=query.executeUpdate();
		return a;
	}

	
	
	@Transactional
	public List<Category> getAllCategories() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		return session.createQuery(" from Category").list();

	}
	
	@Transactional
	public Category addCategory(Category category) {
		Session session = sessionFactory.openSession();
		session.save(category);
		session.flush();	
		return category;
	}

	public Projservice addService(Projservice ser) {
		Session session = sessionFactory.openSession();
		session.save(ser);
		session.flush();	
		return ser;
	}
//	@Transactional
//	public UserProject addProject(UserProject up) {
//		System.out.println("Dao,im am here");
//		Session session = sessionFactory.openSession();
//		session.flush();
//		session.save(up);
//		System.out.println("Insert SuccesfulLLy");
//		return up;
//	}
	@Transactional
	public UserProject getProject(String name) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from UserProject up where up.id.name =:name ");
		query.setString("name", name);
		
		
		UserProject user = (UserProject) query.uniqueResult();
		return user;
	}
	
	@Transactional
	public boolean deleteCategory(Category name) {
		Session session = sessionFactory.openSession();
		String cn=name.getCatergoryName();
		Query query = session.createQuery("delete Category where catergoryName = :cn");
		Query query1 = session.createQuery("delete UserProject where category.catergoryName = :cn");
		query1.setString("cn", cn);
		query.setString("cn", cn);
		 
		query1.executeUpdate();
		int result = query.executeUpdate();
		
		return true;
	}
	
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<UserProject> getAllProjects(Integer userId,String categoryName) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		//List<UserProject> userP=null;
		return session.createQuery(" from UserProject where category.catergoryName =:categoryName").setParameter("categoryName", categoryName).list();
		//return session.createSQLQuery("Select * from user_project where category.catergoryName =:categoryName").setParameter("categoryName", categoryName).list();

	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<UserProject> getAllUserProjects(Integer userId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		//List<UserProject> userP=null;
		return session.createQuery(" from UserProject where id.userId =:userId").setParameter("userId", userId).list();
		//return session.createSQLQuery("Select * from user_project where category.catergoryName =:categoryName").setParameter("categoryName", categoryName).list();

	}

	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<UserProject> getAllBackerProject(String catName) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		//List<UserProject> userP=null;
		String stat="valid";
		return session.createQuery(" from UserProject where  category.catergoryName =:categoryName and status =:stat").setParameter("categoryName", catName).setParameter("stat", stat).list();
		//return session.createSQLQuery("Select * from user_project where category.catergoryName =:categoryName").setParameter("categoryName", categoryName).list();

	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public Integer fetchUserId(String projName) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		//List<UserProject> userP=null;
		return (Integer) session.createSQLQuery("Select user_id from user_project where  name =:projName").setParameter("projName", projName).uniqueResult();
		//return session.createSQLQuery("Select * from user_project where category.catergoryName =:categoryName").setParameter("categoryName", categoryName).list();

	}
	@Transactional
	public BigInteger getProjectCount() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		//List<UserProject> userP=null;
		return (BigInteger) session.createSQLQuery("Select count(*) from user_project").uniqueResult();
		//return session.createSQLQuery("Select * from user_project where category.catergoryName =:categoryName").setParameter("categoryName", categoryName).list();

	}
	@Transactional
	public BigInteger getProjDeadlines() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		//List<UserProject> userP=null;
		return (BigInteger) session.createSQLQuery("Select count(*) from user_project where Amount_Required=Amount_Reached").uniqueResult();
		//return session.createSQLQuery("Select * from user_project where category.catergoryName =:categoryName").setParameter("categoryName", categoryName).list();

	}
	@Transactional
	public BigInteger getNoCategories() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		//List<UserProject> userP=null;
		return (BigInteger) session.createSQLQuery("Select count(*) from category").uniqueResult();
		//return session.createSQLQuery("Select * from user_project where category.catergoryName =:categoryName").setParameter("categoryName", categoryName).list();

	}
	
	public String highestBackers() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		//List<UserProject> userP=null;
		return (String) session.createSQLQuery("select t1.name from user_project t1 inner join (select max(backers) backers1 from user_project) t2 on t1.backers = t2.backers1").uniqueResult();
		//return session.createSQLQuery("Select * from user_project where category.catergoryName =:categoryName").setParameter("categoryName", categoryName).list();

	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Projservice> getAllSerivces(String projName) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		//List<UserProject> userP=null;
		String stat="valid";
		return session.createQuery(" from Projservice where  userProject.id.name =:projName").setParameter("projName", projName).list();
		//return session.createSQLQuery("Select * from user_project where category.catergoryName =:categoryName").setParameter("categoryName", categoryName).list();

	}	@Transactional
	public boolean addPayment(PaymentBean payBean,Integer UserId,Integer ServId) {
		
		// TODO Auto-generated method stub
		System.out.println("im am here payment");
		Session session = sessionFactory.openSession();
//		
//		UserProjectId userProjectId = new UserProjectId(userId, userProjectBean.getName());
//		UserProject userProject = new UserProject();
//		userProject.setId(userProjectId);
//		userProject.setDescription(userProjectBean.getDesc());
//		UserProjectId userProjectId = new UserProjectId(UserId, userProjBean.getName());
//		UserProject up=new UserProject();
//	    up.setId(userProjectId);
//		Category c=new Category();
//		c.setCatergoryName(userProjBean.getCategoryName());
//		up.setDescription(userProjBean.getDesc());
//		up.setCategory(c);
//		up.setFundingDuration(userProjBean.getProjectDuration());
//		// 2017-12-31
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//
//		if (userProjBean.getStartDate()!= null) {
//			try {
//				up.setStartDate(sdf.parse(userProjBean.getStartDate()));
//			} catch (ParseException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		if (userProjBean.getAmount() != null) {
//			up.setAmountRequired(Double.parseDouble(userProjBean.getAmount()));
//		}
		
	     Payment p=new Payment();
	     UserAccount ua=new UserAccount();
	     ua.setId(UserId);
	     Projservice serv=new Projservice();
	     serv.setService(ServId);
	     p.setProjservice(serv);
	     p.setUserAccount(ua);
	     p.setCardNumber(payBean.getCardnumber());
	     p.setModeOfPayment(payBean.getModeofpayment());
	     if (payBean.getPaymentamount() != null) {
	    	 p.setPaymentamount((Double.parseDouble(payBean.getPaymentamount())));
			}
//	    String name=session.createSQLQuery("select ") 
//	    double d=(Double)session.createSQLQuery("").uniqueResult();
		session.save(p);
		session.flush();
		return true;
	}


	

}


