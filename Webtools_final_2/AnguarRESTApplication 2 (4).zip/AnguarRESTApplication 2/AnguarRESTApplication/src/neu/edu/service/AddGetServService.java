package neu.edu.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import neu.edu.bean.AddServiceBean;
import neu.edu.bean.ServiceBean;

import neu.edu.dao.UserDAO;
import neu.edu.entity.Projservice;
import neu.edu.entity.UserProject;
import neu.edu.entity.UserProjectId;



@Service
public class AddGetServService {
	
	@Autowired
	private UserDAO userDAO;
	
	
	public Projservice addService(AddServiceBean addServiceBean,String projName){
		//return userDAO.addProject(categoryBean, userId);
		
		Integer user_id=userDAO.fetchUserId(projName);
		UserProjectId userProjectId = new UserProjectId(user_id, projName);
		UserProject up=new UserProject();
		up.setId(userProjectId);
		
		System.out.println("It is getting into insert page");
		//Category category = new Category();
		
		//UserAccount ua = userDAO.validateUser(userId);
		Projservice ser=new Projservice();
		ser.setUserProject(up);
		ser.setCost(addServiceBean.getAddcost());
		ser.setServicename(addServiceBean.getAddservicename());
		Projservice s=userDAO.addService(ser);
	
		return ser;
	}
//	
//	@Transactional
//	
//	public boolean deleteCategory(String categoryName){
//		//return userDAO.addProject(categoryBean, userId);
//         Category category = new Category();
//		
//		//UserAccount ua = userDAO.validateUser(userId);
//		category.setCatergoryName(categoryName);
//
//		boolean result=userDAO.deleteCategory(category);
//		
//		return result;
//		
//	}
//		public boolean updateCategory(CategoryBean categoryBean, Integer userId) {
//			// TODO Auto-generated method stub
//			//return userDAO.updateProject(userProjectBean, userId);
//			return true;
//		}
		
		@Transactional
		public List<ServiceBean> getServices(String projName) {
			// TODO Auto-generated method stub
			List<Projservice> projservices = userDAO.getAllSerivces(projName);
			
			List<ServiceBean> response = new ArrayList<>();
			for(Projservice projserv:projservices){
				ServiceBean servBean = new ServiceBean();
				servBean.setServicename(projserv.getServicename());
				servBean.setCost(projserv.getCost());
				servBean.setId(projserv.getService().toString());
				response.add(servBean);
			}
			return response;
		}

	}

