package neu.edu.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import neu.edu.bean.CategoryBean;
import neu.edu.bean.UserProjectBean;
import neu.edu.dao.UserDAO;
import neu.edu.entity.Category;
import neu.edu.entity.UserAccount;
import neu.edu.entity.UserProject;

@Service
public class CategoryService {
	
	@Autowired
	private UserDAO userDAO;
	
	
	public Category addCategory(String categoryName){
		//return userDAO.addProject(categoryBean, userId);
		
		System.out.println("It is getting into insert page");
		Category category = new Category();
		
		//UserAccount ua = userDAO.validateUser(userId);
		category.setCatergoryName(categoryName);
		System.out.println("categoryName");
		//category.setUserAccount(ua);
		
		Category cat = userDAO.addCategory(category);
		System.out.println("returned to add category");
		return cat;
	}
	
	@Transactional
	
	public boolean deleteCategory(String categoryName){
		//return userDAO.addProject(categoryBean, userId);
         Category category = new Category();
		
		//UserAccount ua = userDAO.validateUser(userId);
		category.setCatergoryName(categoryName);

		boolean result=userDAO.deleteCategory(category);
		
		return result;
		
	}
		public boolean updateCategory(CategoryBean categoryBean, Integer userId) {
			// TODO Auto-generated method stub
			//return userDAO.updateProject(userProjectBean, userId);
			return true;
		}
		
		@Transactional
		public List<CategoryBean> getAllCategories() {
			// TODO Auto-generated method stub
			List<Category> categories = userDAO.getAllCategories();
			
			List<CategoryBean> response = new ArrayList<>();
			for(Category category:categories){
				CategoryBean categoryBean = new CategoryBean();
				categoryBean.setCategoryName(category.getCatergoryName());
				response.add(categoryBean);
			}
			return response;
		}

	}

