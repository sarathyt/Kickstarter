package neu.edu.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import neu.edu.bean.CategoryBean;
import neu.edu.bean.UpdateProjectStatBean;
import neu.edu.bean.UserProjectBean;
import neu.edu.dao.UserDAO;
import neu.edu.entity.Category;
import neu.edu.entity.UserAccount;
import neu.edu.entity.UserProject;
import neu.edu.entity.UserProjectId;

@Service
public class DisableProjService {
	
	@Autowired
	private UserDAO userDAO;
	
	
	public Integer disableProj(UpdateProjectStatBean updateStatBean,String projName){
		//return userDAO.addProject(categoryBean, userId);
		
		System.out.println("It is getting into insert page");
		UserProjectId id = new UserProjectId();
		
		//UserAccount ua = userDAO.validateUser(userId);
	
		System.out.println("projName"+projName);
		//category.setUserAccount(ua);
		
		Integer response = userDAO.disableProj(projName);
		System.out.println("returned to add category");
		return response;
	}
}


