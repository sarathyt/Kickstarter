package neu.edu.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import neu.edu.bean.AddServiceBean;
import neu.edu.bean.ServiceBean;

import neu.edu.bean.KPIBean;
import neu.edu.dao.UserDAO;
import neu.edu.entity.Projservice;
import neu.edu.entity.UserProject;
import neu.edu.entity.UserProjectId;



@Service
public class ListkpiService {
	
	@Autowired
	private UserDAO userDAO;
	

//	@Transactional
//	
//	public boolean deleteCategory(String categoryName){
//		//return userDAO.addProject(categoryBean, userId);
//         Category category = new Category();
//		
//		//UserAccount ua = userDAO.validateUser(userId);
//		category.setCatergoryName(categoryName);
//
//		boolean result=userDAO.deleteCategory(category);
//		
//		return result;
//		
//	}
//		public boolean updateCategory(CategoryBean categoryBean, Integer userId) {
//			// TODO Auto-generated method stub
//			//return userDAO.updateProject(userProjectBean, userId);
//			return true;
//		}
		

		@Transactional
		public KPIBean getKPI(Integer userId) {
			// TODO Auto-generated method stub
		
			KPIBean response=new KPIBean();
			BigInteger a=userDAO.getProjectCount();
			BigInteger b=userDAO.getProjDeadlines();
			if(a!=null ){
			response.setTotalprojectcount(a.toString());
			}
			if(b!=null){
			response.setProjectreachedgoal(b.toString());
			}
			BigInteger c=userDAO.getNoCategories();
			
			if(c!=null){
				response.setCatergorycount(c.toString());
				}
			response.setProjwithhighestbackers(userDAO.highestBackers());
			return response;
		}

	}

