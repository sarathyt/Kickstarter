package neu.edu.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import neu.edu.bean.UserProjectBean;
import neu.edu.bean.UserRegistrationBean;
import neu.edu.dao.UserDAO;
import neu.edu.entity.Category;
import neu.edu.entity.UserAccount;
import neu.edu.entity.UserProject;
import neu.edu.entity.UserProjectId;

@Service
public class ProjectAddService {

	@Autowired
	private UserDAO userDao;

	public boolean createProject(UserProjectBean userProjBean,Integer UserId) throws ParseException {

		
	
		boolean t = userDao.addProject(userProjBean,UserId);

		return t;
	}

}
