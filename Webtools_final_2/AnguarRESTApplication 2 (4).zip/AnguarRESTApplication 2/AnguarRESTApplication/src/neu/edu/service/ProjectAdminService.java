
package neu.edu.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import neu.edu.bean.UserProjectBean;
import neu.edu.dao.UserDAO;
import neu.edu.entity.UserProject;

@Service
public class ProjectAdminService {
	
	@Autowired
	private UserDAO userDAO;
	
	
	public boolean addProject(UserProjectBean userProjectBean,Integer userId){
		return userDAO.addProject(userProjectBean, userId);
	}

	public boolean updateProject(UserProjectBean userProjectBean, Integer userId) {
		// TODO Auto-generated method stub
		return userDAO.updateProject(userProjectBean, userId);
	}
	
	@Transactional
	public UserProjectBean getProject(String name) {
		// TODO Auto-generated method stub
		UserProject userProject = userDAO.getProject(name);
		
		UserProjectBean response = new UserProjectBean();
		if(userProject!=null){
		if(userProject.getId()!=null){
		response.setName(userProject.getId().getName());
		}
		response.setDesc(userProject.getDescription());
		response.setCategoryName(userProject.getCategory().getCatergoryName());
		response.setStatus(userProject.getStatus());
		response.setLocation(userProject.getLocation());
		response.setStartDate(userProject.getStartDate().toString());
		response.setProjectDuration(userProject.getFundingDuration());
		if(userProject.getBackers()!=null){
			response.setBackers(userProject.getBackers().toString());
			}
			if(	userProject.getAmountReached()!=null){
				response.setAmount(userProject.getAmountReached().toString());
			}
		}
					
		return response;
	}

}