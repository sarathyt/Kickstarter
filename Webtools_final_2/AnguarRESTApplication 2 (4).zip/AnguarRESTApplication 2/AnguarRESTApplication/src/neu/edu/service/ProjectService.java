package neu.edu.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import neu.edu.bean.UserProjectBean;
import neu.edu.dao.UserDAO;
import neu.edu.entity.UserProject;

@Service
public class ProjectService {

	@Autowired
	private UserDAO userDAO;

	public boolean addProject(UserProjectBean userProjectBean, Integer userId) {
		return userDAO.addProject(userProjectBean, userId);
	}

	public boolean updateProject(UserProjectBean userProjectBean, Integer userId) {
		// TODO Auto-generated method stub
		return userDAO.updateProject(userProjectBean, userId);
	}

	@Transactional
	public List<UserProjectBean> getAllProject(Integer userId, String name) {
		// TODO Auto-generated method stub
		List<UserProject> userProjects = userDAO.getAllProjects(userId, name);

		List<UserProjectBean> response = new ArrayList<>();
		for (UserProject userProject : userProjects) {
			UserProjectBean userProjectBean = new UserProjectBean();
			userProjectBean.setName(userProject.getId().getName());
			response.add(userProjectBean);
		}
		return response;
	}

	@Transactional
	public List<UserProjectBean> getAllUserProject(Integer userId) {
		// TODO Auto-generated method stub
		List<UserProject> userProjects = userDAO.getAllUserProjects(userId);

		List<UserProjectBean> response = new ArrayList<>();
		for (UserProject userProject : userProjects) {
			UserProjectBean userProjectBean = new UserProjectBean();
			
			userProjectBean.setName(userProject.getId().getName());
			userProjectBean.setDesc(userProject.getDescription());
			userProjectBean.setCategoryName(userProject.getCategory().getCatergoryName());
			userProjectBean.setStatus(userProject.getStatus());
			userProjectBean.setLocation(userProject.getLocation());
			if(userProject.getBackers()!=null){
			userProjectBean.setBackers(userProject.getBackers().toString());
			}
			if(	userProject.getAmountReached()!=null){
				userProjectBean.setAmount(userProject.getAmountReached().toString());
			}
					
			response.add(userProjectBean);
		}
		return response;
	}
}
