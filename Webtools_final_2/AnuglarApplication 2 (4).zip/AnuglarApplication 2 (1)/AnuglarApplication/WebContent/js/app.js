
/**
 * 
 */
'use strict';
// Step 1: declare modules
 angular.module("authModule",[]);
 angular.module("dashboardModule",[]);
 angular.module("personalModule",[]);
 angular.module("skillModule",[]);
 angular.module("projectModule",[]);
 angular.module("homeModule",[]);
 angular.module("registrationModule",[]);
 angular.module("categoryModule",[]);
 angular.module("projectViewModule",[]);
 angular.module("addProjectModule",[]);
 angular.module("addServiceModule",[]);
 angular.module("addPaymentModule",[]);
 angular.module("controlModule",[]);



 angular.module('appCoreModule', [
	 'ngRoute',
     'ngCookies'
 ]);
//Step 2: Register App
var app = angular.module("app", 
		[
		'appCoreModule',
		 'homeModule',
		 'authModule',
		 'dashboardModule',
		 'personalModule',
		 'skillModule',
		 'projectModule',
		 'registrationModule',
		 'categoryModule',
		 'projectViewModule',
		 'addProjectModule',
		 'addServiceModule',
		 'addPaymentModule',
		 'controlModule'
		 ]);