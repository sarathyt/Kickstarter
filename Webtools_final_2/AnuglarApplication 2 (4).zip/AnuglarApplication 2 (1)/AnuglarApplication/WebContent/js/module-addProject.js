/**
 * 
 */

var addProjectModule = angular.module("addProjectModule", []);
addProjectModule.controller('addProjectController', function($location, $scope,$rootScope,
		addProjectService) {

	var addPrjCtrl = this;

	addPrjCtrl.project = {
		name : "",
		desc : "",
		location:"",
		categoryName : "",
		backers : "",
		amount : "",
		projectDuration:"",
		startDate:"",
	    status:"Pending"
	};

	addPrjCtrl.cancel = function() {
		$location.path('/');
	}


	addPrjCtrl.add = function() {
		console.log(addPrjCtrl.project);
		console.log("UserId in add Project"+$rootScope.userSession.id);
		addProjectService.add($rootScope.userSession.id,addPrjCtrl.project, callbackSuccess,
				callbackError);

	}
	addPrjCtrl.error = false;
	addPrjCtrl.success = false;
	addPrjCtrl.message = "";
	addPrjCtrl.message_sucess="";

	var callbackSuccess = function(data, headers) { // Status
		// Code:200
		//				regCtrl.openComponentModal('Registration Successful');
		//$location.path('/');
		addPrjCtrl.success =true;
		addPrjCtrl.message_sucess = "Project added sucessfully";

	};

	var callbackError = function(data, headers) {
		addPrjCtrl.message = data.message;
		addPrjCtrl.error = true;

	};

});

addProjectModule.factory('addProjectService', function($rootScope, $http,
		$timeout, $cookieStore, $window, APP_CONSTANT, AUTH_EVENTS) {
	var addProjectService = {};

	addProjectService.add = function(id,data, callbackSuccess, callbackError) {

		/*
		 * Use this for real authentication
		 * ----------------------------------------------
		 */
		$http.post(APP_CONSTANT.REMOTE_HOST + '/AddProject/add/'+id, data

		)
		// On Success of $http call
		.success(function(data, status, headers, config) {
			callbackSuccess(data, headers);
		}).error(function(data, status, headers, config) { // IF
			// STATUS
			// CODE
			// NOT
			// 200
			callbackError(data, headers);
		});

	};

	return addProjectService;

});