/**
 * 
 */

var categoryModule = angular.module("categoryModule", []);
categoryModule.controller('categoryController', function($location, $scope,
		categoryService_add, categoryService_get, categoryService_delete,
		$rootScope) {
	var catCtrl = this;

	catCtrl.category = {
		categoryName : ""
	};

	//Adding category
	catCtrl.addCategory = function() {
		categoryService_add.addCategory(catCtrl.category, callBackSucess,
				callBackError);
	};
	//deleting Category
	catCtrl.deleteCategory = function(row1) {
		console.log(row1);
		categoryService_delete.deleteCategory(row1, callBackSucess_Del,
				callBackError_Del);
		catCtrl.init();
	};
	catCtrl.error = false;
	catCtrl.message = "";
	catCtrl.success = false;
	catCtrl.message_success = "";

	var callBackSucess = function(data, headers) {
		catCtrl.success = true;
		catCtrl.message_success = "Category is added succesfully";

	};

	var callBackError = function(data, headers) {

		catCtrl.message = data;
		catCtrl.error = true;

	};

	var callBackSucess_Del = function(data, headers) {

		catCtrl.message = "Category is deleted succesfully";

	};

	var callBackError_Del = function(data, headers) {

		catCtrl.message = data;
		catCtrl.error = true;

	};
	//invoking category service method 

	//init method

	catCtrl.init = function() {
		$scope.error = false;
		$scope.message = "Success";
		console.log("Init Category Called");

		categoryService_get.getCategory(null, function(reponseData) {
			catCtrl.categories = reponseData;
			//console.log(responseData);
		}, function(reponseData) {
			$scope.message = "Failed to load data";
			$scope.error = true;
		});
	}

	catCtrl.viewCategory = function(row) {
		console.log(row);
		$rootScope.categoryName = row;
		console.log($rootScope.categoryName);
		$location.path('/projects/view');

	};

	catCtrl.viewCategory1 = function(row2) {
		console.log(row2);
		$rootScope.categoryName_Backer = row2;
		console.log($rootScope.categoryName_Backer);
		$location.path('/projects/backer');

	};

});

//category servcie
categoryModule.factory('categoryService_get', function($http, $timeout,
		APP_CONSTANT) {
	var categoryService_get = {};

	categoryService_get.getCategory = function(data, callBackSucess,
			callbackError) {

		if (!APP_CONSTANT.DEMO) {

			$http.get(APP_CONSTANT.REMOTE_HOST + '/user/category').success(
					function(data, status, headers, config) {
						callBackSucess(data, headers);
					}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
				if (status == 422) {
					callbackError(data, headers);
				}
			});

		}

	};
	return categoryService_get;
});

//categoryService_add

categoryModule.factory('categoryService_add', function($http, $timeout,
		APP_CONSTANT) {
	var categoryService_add = {};

	categoryService_add.addCategory = function(data, callBackSucess,
			callBackError) {

		if (!APP_CONSTANT.DEMO) {

			$http.post(APP_CONSTANT.REMOTE_HOST + '/user/category/add', data)
					.success(function(data, status, headers, config) {
						callBackSucess(data, headers);
					}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
						if (status == 422) {
							callBackError(data, headers);
						}
					});

		}
	};
	return categoryService_add;
});

categoryModule.factory('categoryService_delete', function($http, $timeout,
		APP_CONSTANT) {
	var categoryService_delete = {};

	categoryService_delete.deleteCategory = function(data, callBackSucess,
			callBackError) {

		if (!APP_CONSTANT.DEMO) {

			$http
					.post(APP_CONSTANT.REMOTE_HOST + '/user/category/delete',
							data).success(
							function(data, status, headers, config) {
								callBackSucess(data, headers);
							}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
						if (status == 422) {
							callBackError(data, headers);
						}
					});

		}
	};
	return categoryService_delete;
});
