/**
 * 
 */

var homeModule = angular.module('homeModule'); // Please dont not use [],
// dependency

homeModule.controller("homeController", function($rootScope, $scope,$window) {
	
});
