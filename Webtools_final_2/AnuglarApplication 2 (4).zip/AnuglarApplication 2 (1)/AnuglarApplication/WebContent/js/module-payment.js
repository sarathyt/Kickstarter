/**
 * 
 */

var addPaymentModule = angular.module("addPaymentModule", []);
addPaymentModule.controller('addPayController', function($location, $scope,paymentService_add,$rootScope) {
	
	var addPayCtrl = this;

	addPayCtrl.pay = {
		paymentamount : "",
		modeofpayment : "",
		cardnumber : "",
		

	};

	//Adding pay
	addPayCtrl.payNow = function() {
		paymentService_add.addPay($rootScope.userSession.id,$rootScope.projPayment,addPayCtrl.pay, callBackSucess,
				callBackError);
	};

	addPayCtrl.success = false;
	addPayCtrl.message_success = "";


	var callBackSucess = function(data, headers) {

		addPayCtrl.success = true;
		addPayCtrl.message_success = "Payment made succesfully";

	};

	var callBackError = function(data, headers) {

		addPayCtrl.message = data;
		addPayCtrl.error = true;

	};
});

	//invoking category service method 

	//init method

//	catCtrl.init = function() {
//		$scope.error = false;
//		$scope.message = "Success";
//		console.log("Init Category Called");
//
//		categoryService_get.getCategory(null, function(reponseData) {
//			catCtrl.categories = reponseData;
//			//console.log(responseData);
//		}, function(reponseData) {
//			$scope.message = "Failed to load data";
//			$scope.error = true;
//		});
//	}

//	catCtrl.viewCategory = function(row) {
//		console.log(row);
//		$rootScope.categoryName = row;
//		console.log($rootScope.categoryName);
//		$location.path('/projects/view');
//
//	};

//	catCtrl.viewCategory1 = function(row2) {
//		console.log(row2);
//		$rootScope.categoryName_Backer = row2;
//		console.log($rootScope.categoryName_Backer);
//		$location.path('/projects/backer');
//
//	};
//
//});

////category servcie
//addPaymentModule.factory('categoryService_get', function($http, $timeout,
//		APP_CONSTANT) {
//	var categoryService_get = {};
//
//	categoryService_get.getCategory = function(data, callBackSucess,
//			callbackError) {
//
//		if (!APP_CONSTANT.DEMO) {
//
//			$http.get(APP_CONSTANT.REMOTE_HOST + '/user/category').success(
//					function(data, status, headers, config) {
//						callBackSucess(data, headers);
//					}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
//				if (status == 422) {
//					callbackError(data, headers);
//				}
//			});
//
//		}
//
//	};
//	return categoryService_get;
//});

//categoryService_add

addPaymentModule.factory('paymentService_add', function($http, $timeout,
		APP_CONSTANT) {
	var paymentService_add = {};

	paymentService_add.addPay = function(id,servId,data, callBackSucess,
			callBackError) {

		if (!APP_CONSTANT.DEMO) {

			$http.post(APP_CONSTANT.REMOTE_HOST + '/backer/payment/add/'+id+'/'+servId, data)
					.success(function(data, status, headers, config) {
						callBackSucess(data, headers);
					}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
						if (status == 422) {
							callBackError(data, headers);
						}
					});

		}
	};
	return paymentService_add;
});

//addPaymentModule.factory('categoryService_delete', function($http, $timeout,
//		APP_CONSTANT) {
//	var categoryService_delete = {};
//
//	categoryService_delete.deleteCategory = function(data, callBackSucess,
//			callBackError) {
//
//		if (!APP_CONSTANT.DEMO) {
//
//			$http
//					.post(APP_CONSTANT.REMOTE_HOST + '/user/category/delete',
//							data).success(
//							function(data, status, headers, config) {
//								callBackSucess(data, headers);
//							}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
//						if (status == 422) {
//							callBackError(data, headers);
//						}
//					});
//
//		}
//	};
//	return categoryService_delete;
//});
