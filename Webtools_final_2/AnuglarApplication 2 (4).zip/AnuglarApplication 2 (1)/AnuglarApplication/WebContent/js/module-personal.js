/**
 * 
 */
var personalModule = angular.module('personalModule');
personalModule.controller('personalContoller', function($scope) {
	$scope.message = "This is personal";

});