/**
 * 
 */

var projectModule = angular.module('projectModule');
projectModule.controller('projectController', function($scope, $rootScope,
		$location, projectService,projServiceUser,projServiceBacker) {
	var prjCtrl = this;

	prjCtrl.messageDash = "Welcome " + $rootScope.userSession.name;

	prjCtrl.init = function() {

		console.log('init called')
		projectService.listProject($rootScope.userSession.id,
				$rootScope.categoryName, null,

				function(reponseData) {
					$scope.message = "Success";
					$scope.error = false;
					console.log(reponseData);
					prjCtrl.projects = reponseData;
				}, function(reponseData) {
					$scope.message = "Failed to load data";
					$scope.error = true;
				});
	}

	prjCtrl.init1 = function() {

		console.log('init1 called')
		projServiceUser.listProjectUser($rootScope.userSession.id, null,

				function(reponseData) {
					$scope.message_user = "Success";
					$scope.error = false;
					console.log(reponseData);
					prjCtrl.projectsUser = reponseData;
				}, function(reponseData) {
					$scope.message_user = "Failed to load data";
					$scope.error = true;
				});
	}
	
	prjCtrl.init2 = function() {

		console.log('init2 called')
		projServiceBacker.listProjectBacker($rootScope.categoryName_Backer, null,

				function(reponseData) {
					$scope.message_user = "Success";
					$scope.error = false;
					console.log(reponseData);
					prjCtrl.projectsBacker = reponseData;
				}, function(reponseData) {
					$scope.message_user = "Failed to load data";
					$scope.error = true;
				});
	}
	prjCtrl.viewProject = function(row) {
		console.log(row);
		$rootScope.projectName = row;
		console.log($rootScope.projectName);
		$location.path('/project/view');

	};
	
	
	prjCtrl.viewProject1 = function(row) {
		console.log("viewProject1"+row);
		$rootScope.projectNameBacker = row;
		console.log($rootScope.projectNameBacker);
		$location.path('/view/project/backer');

	};

	prjCtrl.add1 = function(row) {
		console.log(row);
		//console.log("UserId in add Project"+$rootScope.userSession.id);
		$rootScope.serviceAdd = row;
		console.log($rootScope.serviceAdd);
		$location.path('/AddServices');

	}


});

projectModule.factory('projectService',
		function($http, $timeout, APP_CONSTANT) {
			var projectService = {};

			projectService.listProject = function(id, categoryName, data,
					callback, callbackError) {

				{

					$http.get(
							APP_CONSTANT.REMOTE_HOST + '/user/' + id+
								'/'	+ categoryName + '/project').success(
							function(data, status, headers, config) {
								callback(data);
							}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
						if (status == 422) {
							callbackError(data);
						}
					});

				}
			};

			return projectService;
		});

projectModule.factory('projServiceUser',
		function($http, $timeout, APP_CONSTANT) {
			var projServiceUser = {};

			projServiceUser.listProjectUser = function(id, data,
					callback, callbackError) {

				{

					$http.get(
							APP_CONSTANT.REMOTE_HOST + '/user/' + id+'/project'
								).success(
							function(data, status, headers, config) {
								callback(data);
							}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
						if (status == 422) {
							callbackError(data);
						}
					});

				}
			};

			return projServiceUser;
		});


projectModule.factory('projServiceBacker',
		function($http, $timeout, APP_CONSTANT) {
			var projServiceBacker = {};

			projServiceBacker.listProjectBacker = function(categoryNameBacker, data,
					callback, callbackError) {

				{

					$http.get(
							APP_CONSTANT.REMOTE_HOST + '/user/backer/' +categoryNameBacker
								).success(
							function(data, status, headers, config) {
								callback(data);
							}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
						if (status == 422) {
							callbackError(data);
						}
					});

				}
			};

			return projServiceBacker;
		});