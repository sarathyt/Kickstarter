/**
 * 
 */
var registrationModule = angular.module("registrationModule", []);
registrationModule.controller('registrationController', function($location,
		$scope, registrationService) {

	var regCtrl = this;

	regCtrl.registration = {
		title:"",
		role : "",
		firstName : "",
		lastName : "",
		username : "",
		password : "",
		phone:"",
		dob:"",
		email : ""
	};




	regCtrl.cancel = function() {
		$location.path('/');
	}

	regCtrl.register = function() {
		console.log(regCtrl.registration);
		registrationService.register(regCtrl.registration, callbackSuccess,
				callbackError);

	}

	regCtrl.error = false;
	regCtrl.message = "";
	regCtrl.success = false;
	regCtrl.message_success = "";

	var callbackSuccess = function(data, headers) { // Status
		// Code:200
//			regCtrl.openComponentModal('Registration Successful');
			
			regCtrl.success = true;
			regCtrl.message_success = "Registration Successful";
			$location.path('/');


	};

	var callbackError = function(data, headers) {
		regCtrl.message ="Registration Unsucessful";
		regCtrl.error = true;

	};



});

registrationModule.factory('registrationService', function($rootScope, $http,
		$timeout, $cookieStore, $window, APP_CONSTANT, AUTH_EVENTS) {
	var regService = {};

	regService.register = function(data, callbackSuccess, callbackError) {
		

			/*
			 * Use this for real authentication
			 * ----------------------------------------------
			 */
			$http.post(APP_CONSTANT.REMOTE_HOST + '/registration/add', data

			)
			// On Success of $http call
			.success(function(data, status, headers, config) {
				callbackSuccess(data, headers);
			}).error(function(data, status, headers, config) { // IF
				// STATUS
				// CODE
				// NOT
				// 200
				callbackError(data, headers);
			});
		

	};
	
	return regService;

});