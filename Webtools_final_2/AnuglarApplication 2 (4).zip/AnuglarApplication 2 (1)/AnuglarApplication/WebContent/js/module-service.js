/**
 * 
 */
var addServiceModule = angular.module("addServiceModule", []);
addServiceModule.controller('addServiceController', function($location,$rootScope,
		$scope, addSerService,getSerService) {

	var addSerCtrl = this;

	addSerCtrl.service = {
		service:"",
		servicename:"",
		cost : ""
	};


	addSerCtrl.serviceAdd = {
			addservicename:"",
			addcost : ""
		};

	addSerCtrl.cancel = function() {
		$location.path('/');
	}

	addSerCtrl.addService = function() {
		console.log(addSerCtrl.serviceAdd);
		console.log($rootScope.serviceAdd);
		addSerService.addSer($rootScope.serviceAdd,addSerCtrl.serviceAdd, callbackSuccess,
				callbackError);

	}

	addSerCtrl.makePay = function(row) {
		console.log(row);
		$rootScope.projPayment = row;
		console.log($rootScope.projPayment);
		$location.path('/AddPayment');

	};
	addSerCtrl.error = false;
	addSerCtrl.message = "";
	addSerCtrl.success = "";
	addSerCtrl.message_sucess="";
	var callbackSuccess = function(data, headers) { // Status
		// Code:200
//			addSerCtrl.openComponentModal('Registration Successful');
		//	$location.path('/');
		addSerCtrl.success =true;
		addSerCtrl.message_sucess="Service added successfully";


	};

	var callbackError = function(data, headers) {
		addSerCtrl.message = data.message;
		addSerCtrl.error = true;

	};
	
	addSerCtrl.init=function(){
		$scope.error=false;
		$scope.message="Success";
		console.log("Init Category Called");
		
		getSerService.getService($rootScope.projectNameBacker,null,function (reponseData){
			addSerCtrl.services=reponseData;
			console.log(reponseData);
		},
		function (reponseData){
			$scope.message="Failed to load data";
			$scope.error=true;
	});
	}
	
	



});

addServiceModule.factory('addSerService', function($rootScope, $http,
		$timeout, $cookieStore, $window, APP_CONSTANT, AUTH_EVENTS) {
	var addSerService = {};

	addSerService.addSer = function(projName,data, callbackSuccess, callbackError) {
		

			/*
			 * Use this for real authentication
			 * ----------------------------------------------
			 */
			$http.post(APP_CONSTANT.REMOTE_HOST + '/project/service/add/'+projName, data

			)
			// On Success of $http call
			.success(function(data, status, headers, config) {
				callbackSuccess(data, headers);
			}).error(function(data, status, headers, config) { // IF
				// STATUS
				// CODE
				// NOT
				// 200
				callbackError(data, headers);
			});
		

	};
	
	return addSerService;

});


addServiceModule.factory('getSerService', function($http,$timeout,APP_CONSTANT) {
	var getSerService = {};
	
	getSerService.getService = function (projName,data,callBack,callBackError) {
	
	if(!APP_CONSTANT.DEMO){

	
			 $http.get(
         			APP_CONSTANT.REMOTE_HOST+'/project/services/'+projName
         			).success(function (data, status,headers, config) {
         				callBack(data);
        			})
        			.error(function (data, status, headers, config) { // IF STATUS CODE NOT 200
        					if(status== 422){
        						callBackError(data);
        					}
        			});
			
		}
	};
	return getSerService;
});