/**
 * 
 */

var projectViewModule = angular.module('projectViewModule');
projectViewModule.controller('projectViewController', function($scope, $rootScope,
		$location, projectViewService,projectViewServiceBacker,projectDisableService) {
	var prjViewCtrl = this;

	prjViewCtrl.messageDash = "Welcome " + $rootScope.userSession.name;


	prjViewCtrl.disableProj = {
	    status:"invalid"
	};
	prjViewCtrl.init = function() {

		console.log('init called')
		projectViewService.view(
				$rootScope.projectName, null,

				function(reponseData) {
					$scope.message = "Success";
					$scope.error = false;
					console.log(reponseData);
					prjViewCtrl.project = reponseData;
				}, function(reponseData) {
					$scope.message = "Failed to load data";
					$scope.error = true;
				});
	}
	prjViewCtrl.init2 = function() {

		console.log('init2 called')
		projectViewServiceBacker.viewBackerProj(
				$rootScope.projectNameBacker, null,

				function(reponseData) {
					$scope.message = "Success";
					$scope.error = false;
					console.log(reponseData);
					prjViewCtrl.projectBacker = reponseData;
				}, function(reponseData) {
					$scope.message = "Failed to load data";
					$scope.error = true;
				});
	}
	prjViewCtrl.disableProject = function(row) {

		console.log(row.name);
		console.log('disable is called');
		projectDisableService.disableProj(
				row.name,prjViewCtrl.disableProj ,

				function(reponseData) {
					$scope.message_disableProj = "Disabled Project";
					$scope.error = false;
					console.log(reponseData);
					prjViewCtrl.disableProj = reponseData;
				}, function(reponseData) {
					$scope.message = "Failed to load data";
					$scope.error = true;
				});
	}

	prjViewCtrl.viewProject = function(row) {
		console.log(row);
		$rootScope.project = row.project;
		console.log($rootScope.project);
		$location.path('/project/view');

	};
	prjViewCtrl.makePayment = function(row1) {
		console.log(row1);
		$rootScope.projecServ = row1;
		console.log($rootScope.projecServ);
		$location.path('/ViewService');

	};
	
	prjViewCtrl.viewProjectBacker = function(row2) {
		console.log(row2);
		$rootScope.project = row2.project;
		console.log($rootScope.project);
		$location.path('/view/project/backer');

	};


});

projectModule.factory('projectViewService',function($http, $timeout, APP_CONSTANT) {
			var projectViewService = {};

			projectViewService.view = function(projectName, data,
					callback, callbackError) {

				{

					$http.get(
							APP_CONSTANT.REMOTE_HOST + '/user/project/'+projectName).success(
							function(data, status, headers, config) {
								callback(data);
							}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
						if (status == 422) {
							callbackError(data);
						}
					});

				}
			};

			return projectViewService;
		});

projectModule.factory('projectViewServiceBacker',function($http, $timeout, APP_CONSTANT) {
			var projectViewServiceBacker = {};

			projectViewServiceBacker.viewBackerProj = function(projectNameBack, data,
					callback, callbackError) {

				{

					$http.get(
							APP_CONSTANT.REMOTE_HOST + '/user/project/'+projectNameBack).success(
							function(data, status, headers, config) {
								callback(data);
							}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
						if (status == 422) {
							callbackError(data);
						}
					});

				}
			};

			return projectViewServiceBacker;
		});

projectModule.factory('projectDisableService',function($http, $timeout, APP_CONSTANT) {
	var projectDisableService = {};

	projectDisableService.disableProj= function(projectNamedisable, data,
			callback, callbackError) {

		{

			console.log("ProjectDisableService");
			$http.post(
					APP_CONSTANT.REMOTE_HOST + '/admin/project/disable/'+projectNamedisable,data).success(
					function(data, status, headers, config) {
						callback(data);
					}).error(function(data, status, headers, config) { // IF STATUS CODE NOT 200
				if (status == 422) {
					callbackError(data);
				}
			});

		}
	};

	return projectDisableService;
});